

<?php $__env->startSection('title','Admin Dashboard'); ?>

<?php $__env->startSection('content'); ?>

<div class="container my-4">

    
    <div class="admin-header mb-5">
        <h2 class="fw-bold mb-1">Admin Control Panel</h2>
        <p class="text-muted">
            Monitoring sistem, statistik real-time & kontrol aplikasi
        </p>
    </div>

    
    <div class="row g-4 mb-5">

        <div class="col-xl-3 col-md-6">
            <div class="card stat-glass bg-gradient-primary stat-hover">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <span class="stat-label">Total Produk</span>
                            <h2 class="stat-value"><?php echo e($totalProducts); ?></h2>
                        </div>
                        <i class="bi bi-box-seam stat-icon"></i>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6">
            <div class="card stat-glass bg-gradient-success stat-hover">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <span class="stat-label">Total Klik</span>
                            <h2 class="stat-value" id="total-clicks">
                                <?php echo e(number_format($totalClicks)); ?>

                            </h2>
                        </div>
                        <i class="bi bi-cursor-fill stat-icon"></i>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6">
            <div class="card stat-glass bg-gradient-warning stat-hover">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <span class="stat-label">Kategori</span>
                            <h2 class="stat-value"><?php echo e($totalCategories); ?></h2>
                        </div>
                        <i class="bi bi-tags-fill stat-icon"></i>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6">
            <div class="card stat-glass bg-gradient-dark stat-hover">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <span class="stat-label">Pesanan</span>
                            <h2 class="stat-value" id="total-orders">
                                <?php echo e($totalOrders); ?>

                            </h2>
                        </div>
                        <i class="bi bi-receipt stat-icon"></i>
                    </div>
                </div>
            </div>
        </div>

    </div>

    
    <div class="row g-4 mb-5">

        <div class="col-md-6">
            <div class="card insight-card">
                <div class="card-body">
                    <h6 class="fw-bold mb-3">
                        <i class="bi bi-graph-up me-2"></i> Insight Sistem
                    </h6>
                    <ul class="insight-list">
                        <li>Total klik produk meningkat hari ini</li>
                        <li>Produk paling sering dilihat tersedia</li>
                        <li>Pesanan baru masuk real-time</li>
                    </ul>
                </div>
            </div>
        </div>

        <div class="col-md-6">
            <div class="card insight-card">
                <div class="card-body">
                    <h6 class="fw-bold mb-3">
                        <i class="bi bi-lightning-fill me-2"></i> Aksi Cepat
                    </h6>
                    <div class="d-grid gap-2">
                        <a href="<?php echo e(route('user.dashboard')); ?>" target="_blank"
                           class="btn btn-outline-primary">
                            Preview Dashboard User
                        </a>
                        <a href="<?php echo e(url('/admin/products')); ?>"
                           class="btn btn-outline-success">
                            Kelola Produk
                        </a>
                        <a href="<?php echo e(route('admin.orders')); ?>"
                           class="btn btn-outline-warning">
                            Kelola Pesanan
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    
    <div class="row g-4 mb-5">

        <div class="col-md-6">
            <div class="card insight-card h-100">
                <div class="card-body d-flex flex-column">
                    <h6 class="fw-bold mb-3">
                        <i class="bi bi-cash-stack me-2"></i> Grafik Pendapatan
                    </h6>

                    <div class="chart-wrapper">
                        <canvas id="salesChart"></canvas>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-6">
            <div class="card insight-card h-100">
                <div class="card-body d-flex flex-clumn">
                    <h6 class="fw-bold mb-3">
                        <i class="bi bi-graph-up-arrow me-2"></i> Grafik Klik Produk
                    </h6>
                    <div class="chart-wrapper">
                        <canvas id="clickChart"></canvas>
                    </div>
                </div>
            </div>
        </div>

    </div>

</div>

<?php $__env->startSection('scripts'); ?>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script>
/* ================= GLOBAL STYLE ================= */
const primaryColor = '#6366f1';
const successColor = '#22c55e';
const gridColor = 'rgba(148,163,184,.15)';
const fontFamily = "'Inter', sans-serif";

/* ================= FORMAT RUPIAH ================= */
const formatRupiah = (value) => {
    return 'Rp ' + new Intl.NumberFormat('id-ID').format(value);
};

/* ================= REVENUE CHART ================= */
const revenueChart = new Chart(
    document.getElementById('salesChart'),
    {
        type: 'line',
        data: {
            labels: <?php echo json_encode($revenueLabels, 15, 512) ?>, // tanggal / bulan
            datasets: [{
                label: 'Pendapatan',
                data: <?php echo json_encode($revenueData, 15, 512) ?>, // SUM(total)
                borderColor: primaryColor,
                backgroundColor: 'rgba(99,102,241,.25)',
                fill: true,
                tension: 0.45,
                borderWidth: 3,
                pointRadius: 4,
                pointBackgroundColor: primaryColor
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            animation: {
                duration: 1400,
                easing: 'easeOutQuart'
            },
            plugins: {
                legend: { display: false },
                tooltip: {
                    callbacks: {
                        label: (context) => formatRupiah(context.raw)
                    }
                }
            },
            scales: {
                x: {
                    grid: { color: gridColor },
                    ticks: { font: { family: fontFamily }}
                },
                y: {
                    grid: { color: gridColor },
                    ticks: {
                        callback: (value) => formatRupiah(value),
                        font: { family: fontFamily }
                    }
                }
            }
        }
    }
);

/* ================= CLICK PRODUCT CHART ================= */
const clickChart = new Chart(
    document.getElementById('clickChart'),
    {
        type: 'bar',
        data: {
            labels: <?php echo json_encode($clickLabels, 15, 512) ?>, // nama produk
            datasets: [{
                label: 'Klik Produk',
                data: <?php echo json_encode($clickData, 15, 512) ?>,
                backgroundColor: successColor,
                borderRadius: 8,
                barThickness: 30
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            animation: {
                duration: 1200,
                easing: 'easeOutBounce'
            },
            plugins: {
                legend: { display: false }
            },
            scales: {
                x: {
                    grid: { display: false },
                    ticks: { font: { family: fontFamily }}
                },
                y: {
                    grid: { color: gridColor },
                    ticks: {
                        precision: 0,
                        font: { family: fontFamily }
                    }
                }
            }
        }
    }
);

/* ================= REALTIME CLICK ================= */
window.Echo.channel('admin-dashboard')
.listen('.product.viewed', (data) => {
    clickChart.data.labels = data.labels;
    clickChart.data.datasets[0].data = data.values;
    clickChart.update('active');
});

/* ================= REALTIME REVENUE ================= */
window.Echo.channel('admin-dashboard')
.listen('.order.created', (data) => {
    revenueChart.data.labels = data.labels;
    revenueChart.data.datasets[0].data = data.values;
    revenueChart.update('active');
});
</script>

<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Coding\bootcampeduwork\ecommerce\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>