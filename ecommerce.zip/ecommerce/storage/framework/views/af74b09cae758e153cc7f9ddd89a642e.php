

<?php $__env->startSection('title','Admin Dashboard'); ?>

<?php $__env->startSection('content'); ?>

<div class="container my-4">

    <h2 class="mb-4 fw-bold">Dashboard</h2>

    <div class="row g-4 mb-4">

        
        <div class="col-md-3">
            <div class="card stat-card bg-primary text-white shadow-sm">
                <div class="card-body d-flex align-items-center justify-content-between">
                    <div>
                        <h6 class="fw-semibold mb-1">Total Produk</h6>
                        <h2 class="fw-bold mb-0"><?php echo e($totalProducts); ?></h2>
                    </div>
                    <div class="stat-icon">
                        <i class="bi bi-box-seam"></i>
                    </div>
                </div>
            </div>
        </div>

        
        <div class="col-md-3">
            <div class="card stat-card bg-success text-white shadow-sm">
                <div class="card-body d-flex align-items-center justify-content-between">
                    <div>
                        <h6 class="fw-semibold mb-1">Total Klik Produk</h6>
                        <h2 class="fw-bold mb-0" id="total-clicks">
                            <?php echo e(number_format($totalClicks)); ?>

                        </h2>
                    </div>
                    <div class="stat-icon">
                        <i class="bi bi-cursor-fill"></i>
                    </div>
                </div>
            </div>
        </div>

        
        <div class="col-md-3">
            <div class="card stat-card bg-warning text-dark shadow-sm">
            <div class="card-body d-flex align-items-center justify-content-between">
                <div>
                    <h6 class="fw-semibold mb-1">Kategori Produk</h6>
                    <h2 class="fw-bold mb-0"><?php echo e($totalCategories); ?></h2>
                </div>
                <div class="stat-icon text-dark">
                    <i class="bi bi-tags-fill"></i>
                </div>
            </div>
            </div>
        </div>

        
        <div class="col-md-3">
            <div class="card stat-card bg-dark text-white shadow-sm">
                <div class="card-body d-flex align-items-center justify-content-between">
                    <div>
                        <h6 class="fw-semibold mb-1">Total Pesanan</h6>
                        <h2 class="fw-bold mb-0" id="total-orders">
                            <?php echo e($totalOrders); ?>

                        </h2>
                    </div>
                    <div class="stat-icon">
                        <i class="bi bi-receipt"></i>
                    </div>
                </div>
            </div>
        </div>

    </div>

    
    <div class="row mt-5 g-4">

        <div class="col-md-6">
            <div class="card shadow-sm h-100">
                <div class="card-body text-center">
                    <h5>Kelola Produk</h5>
                    <p class="text-muted">Tambah, edit, dan hapus produk</p>
                    <a href="<?php echo e(url('/admin/products')); ?>" class="btn btn-primary">
                        Lihat Produk
                    </a>
                </div>
            </div>
        </div>

        <div class="col-md-6">
            <div class="card shadow-sm h-100">
                <div class="card-body text-center">
                    <h5>Kelola Pesanan</h5>
                    <p class="text-muted">Lihat dan update status pesanan</p>
                    <a href="<?php echo e(route('admin.orders')); ?>" class="btn btn-success">
                        Lihat Pesanan
                    </a>
                </div>
            </div>
        </div>

    </div>

</div>

<?php $__env->stopSection(); ?>





<?php $__env->startSection('scripts'); ?>
<script>
window.Echo.channel('admin-dashboard')
    .listen('.product.viewed', (data) => {
        let el = document.getElementById('total-clicks');
        if(el){
            el.innerText = Number(data.total_clicks).toLocaleString();
        }
    });

window.Echo.channel('admin-dashboard')
    .listen('.order.created', (data) => {
        let el = document.getElementById('total-orders');
        if(el){
            el.innerText = data.total_orders;
        }
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Coding\bootcampeduwork\ecommerce\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>