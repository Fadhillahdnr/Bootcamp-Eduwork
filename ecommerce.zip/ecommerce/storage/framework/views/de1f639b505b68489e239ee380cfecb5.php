<?php
    use Illuminate\Support\Str;
?>



<?php $__env->startSection('title','Beranda'); ?>

<?php $__env->startSection('content'); ?>


<?php if(session('success')): ?>
    <div class="alert alert-success text-center shadow-sm">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>


<?php if(auth()->check() && auth()->user()->role === 'admin'): ?>
<div class="alert alert-warning d-flex align-items-center justify-content-center gap-2 shadow-sm mb-4">
    <i class="bi bi-eye-fill fs-5"></i>
    <span>
        Anda sedang melihat <strong>Dashboard User (Preview Mode)</strong>
    </span>
</div>
<?php endif; ?>


<div class="text-center my-5">
    <h1 class="fw-bold display-6">Selamat Datang di Toko Kami</h1>
    <p class="text-muted fs-5">
        Temukan produk terbaik dengan kualitas terpercaya
    </p>
</div>


<form method="GET" action="<?php echo e(route('user.dashboard')); ?>" class="mb-5">
    <div class="row justify-content-center">
        <div class="col-md-4">
            <div class="input-group shadow-sm">
                <span class="input-group-text bg-white">
                    <i class="bi bi-tags"></i>
                </span>
                <select name="category" class="form-select" onchange="this.form.submit()">
                    <option value="">Semua Kategori</option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($category->id); ?>"
                            <?php echo e(request('category') == $category->id ? 'selected' : ''); ?>>
                            <?php echo e($category->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
    </div>
</form>


<div class="row g-4">
<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6">
        <div class="product-card-premium">

            
            <div class="product-image-wrapper">
                <img src="<?php echo e(asset('storage/'.$product->image)); ?>"
                     class="product-img"
                     alt="<?php echo e($product->name); ?>">

                <span class="badge badge-category">
                    <?php echo e($product->category->name); ?>

                </span>

                <span class="badge badge-views">
                    <i class="bi bi-eye"></i>
                    <?php echo e(number_format($product->views ?? 0)); ?>

                </span>
            </div>

            
            <div class="product-body">
                <h6 class="product-title">
                    <?php echo e($product->name); ?>

                </h6>

                <p class="product-desc">
                    <?php echo e(\Illuminate\Support\Str::limit($product->description, 80)); ?>

                </p>

                <div class="product-footer">
                    <div class="product-price">
                        Rp <?php echo e(number_format($product->price)); ?>

                    </div>

                    <div class="product-actions">
                        <a href="<?php echo e(route('product.show', $product->id)); ?>"
                           class="btn btn-outline-primary btn-sm">
                            <i class="bi bi-eye"></i>
                        </a>

                        <a href="<?php echo e(route('cart.add', $product->id)); ?>"
                           class="btn btn-primary btn-sm">
                            <i class="bi bi-cart-plus"></i>
                        </a>
                    </div>
                </div>
            </div>

        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>



<div class="d-flex justify-content-center mt-5">
    <?php echo e($products->links()); ?>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Coding\bootcampeduwork\ecommerce\resources\views/user/dashboard.blade.php ENDPATH**/ ?>