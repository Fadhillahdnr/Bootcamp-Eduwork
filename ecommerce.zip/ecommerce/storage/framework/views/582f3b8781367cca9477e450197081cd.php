<?php $__env->startSection('title','Keranjang'); ?>

<?php $__env->startSection('content'); ?>
<div class="container my-5">
    <h3 class="fw-bold mb-4">🛒 Keranjang Belanja</h3>

    
    <?php $__currentLoopData = ['success','error']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(session($msg)): ?>
            <div class="alert alert-<?php echo e($msg == 'success' ? 'success' : 'danger'); ?> alert-dismissible fade show">
                <?php echo e(session($msg)); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php if($cart && $cart->items->count()): ?>
        <div class="row">
            
            <div class="col-lg-8">
                <?php $grandTotal = 0; ?>

                <?php $__currentLoopData = $cart->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $total = $item->product->price * $item->qty;
                        $grandTotal += $total;
                    ?>

                    <div class="card mb-3 shadow-sm border-0">
                        <div class="card-body">
                            <div class="row align-items-center">
                                <div class="col-md-2 text-center">
                                    <img src="<?php echo e(asset('storage/'.$item->product->image)); ?>"
                                         class="img-fluid rounded"
                                         style="max-height:80px">
                                </div>

                                <div class="col-md-4">
                                    <h6 class="fw-semibold mb-1">
                                        <?php echo e($item->product->name); ?>

                                    </h6>
                                    <small class="text-muted">
                                        Rp <?php echo e(number_format($item->product->price)); ?>

                                    </small>
                                </div>

                                <div class="col-md-3 text-center">
                                    <div class="btn-group">
                                        <a href="<?php echo e(route('cart.decrease', $item->id)); ?>"
                                           class="btn btn-outline-secondary btn-sm">−</a>

                                        <span class="btn btn-light btn-sm disabled">
                                            <?php echo e($item->qty); ?>

                                        </span>

                                        <a href="<?php echo e(route('cart.increase', $item->id)); ?>"
                                           class="btn btn-outline-secondary btn-sm">+</a>
                                    </div>
                                </div>

                                <div class="col-md-2 text-end fw-semibold">
                                    Rp <?php echo e(number_format($total)); ?>

                                </div>

                                <div class="col-md-1 text-end">
                                    <a href="<?php echo e(route('cart.remove', $item->id)); ?>"
                                       class="btn btn-sm btn-outline-danger">
                                        ✕
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            
            <div class="col-lg-4">
                <div class="card shadow-sm border-0">
                    <div class="card-body">
                        <h5 class="fw-bold mb-3">Ringkasan Belanja</h5>

                        <div class="d-flex justify-content-between mb-2">
                            <span>Total Item</span>
                            <span><?php echo e($cart->items->sum('qty')); ?></span>
                        </div>

                        <hr>

                        <div class="d-flex justify-content-between fw-bold fs-5 mb-4">
                            <span>Total</span>
                            <span>Rp <?php echo e(number_format($grandTotal)); ?></span>
                        </div>

                        <a href="<?php echo e(route('checkout.index')); ?>"
                           class="btn btn-primary w-100 mb-2">
                            Checkout
                        </a>

                        <a href="<?php echo e(route('beranda')); ?>"
                           class="btn btn-outline-secondary w-100">
                            Lanjut Belanja
                        </a>
                    </div>
                </div>
            </div>
        </div>
    <?php else: ?>
        
        <div class="text-center py-5">
            <img src="https://cdn-icons-png.flaticon.com/512/2038/2038854.png"
                 width="120" class="mb-3">

            <h5 class="fw-bold">Keranjang Masih Kosong</h5>
            <p class="text-muted">Yuk mulai belanja produk favoritmu</p>

            <a href="<?php echo e(route('beranda')); ?>" class="btn btn-primary">
                Mulai Belanja
            </a>
        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Coding\bootcampeduwork\ecommerce\resources\views/user/cart.blade.php ENDPATH**/ ?>