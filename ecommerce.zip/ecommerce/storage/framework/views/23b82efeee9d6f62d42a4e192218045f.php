<div class="alert alert-success" role="alert">
    <?php echo e($slot); ?>

</div><?php /**PATH C:\Coding\bootcampeduwork\ecommerce\resources\views\components\alert.blade.php ENDPATH**/ ?>