

<?php $__env->startSection('title','Edit Produk'); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="d-flex justify-content-between align-items-center my-4">
        <h2>Edit Produk</h2>
        <a href="<?php echo e(url()->previous()); ?>" class="btn btn-secondary me-2">
            ← Kembali
        </a>    
    </div>

    <form method="POST"
          action="<?php echo e(url('/admin/products/'.$product->id)); ?>"
          enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="mb-3">
            <label>Nama Produk</label>
            <input type="text" name="name"
                   value="<?php echo e(old('name', $product->name)); ?>"
                   class="form-control">
        </div>

        <div class="mb-3">
            <label>Deskripsi</label>
            <textarea name="description"
                      class="form-control"><?php echo e(old('description', $product->description)); ?></textarea>
        </div>

        <div class="mb-3">
            <label>Harga</label>
            <input type="number" name="price"
                   value="<?php echo e(old('price', $product->price)); ?>"
                   class="form-control">
        </div>

        <div class="mb-3">
            <label>Gambar Sekarang</label><br>
            <img src="<?php echo e(asset('storage/'.$product->image)); ?>"
                 width="120" class="img-thumbnail">
        </div>

        <div class="mb-3">
            <label>Ganti Gambar (opsional)</label>
            <input type="file" name="image" class="form-control">
        </div>

        <button class="btn btn-primary">Update</button>
        <a href="<?php echo e(url('/admin/products')); ?>" class="btn btn-secondary">
            Kembali
        </a>
    </form>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Coding\bootcampeduwork\ecommerce\resources\views\admin\products\edit.blade.php ENDPATH**/ ?>