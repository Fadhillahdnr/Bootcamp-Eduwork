

<?php $__env->startSection('title', $product->name); ?>

<?php $__env->startSection('content'); ?>
<div class="container my-5">
    <div class="row">
        <div class="col-md-6">
            <img src="<?php echo e(asset('storage/'.$product->image)); ?>"
                 class="img-fluid rounded">
        </div>

        <div class="col-md-6">
            <h2><?php echo e($product->name); ?></h2>
            <p class="text-muted">
                Rp <?php echo e(number_format($product->price)); ?>

            </p>

            <p><?php echo e($product->description); ?></p>

            <a href="<?php echo e(route('cart.add', $product->id)); ?>" class="btn btn-success mt-2">
                Tambah ke Keranjang
            </a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Coding\bootcampeduwork\ecommerce\resources\views/user/product-detail.blade.php ENDPATH**/ ?>