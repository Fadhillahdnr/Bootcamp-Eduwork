<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="<?php echo e(route('beranda')); ?>">Toko Online</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item">
            <a class="nav-link <?php echo e(request()->routeIs('beranda') ? 'active' : ''); ?>"
            href="<?php echo e(route('beranda')); ?>">
            Beranda
            </a>
        </li>

        <li class="nav-item">
            <a class="nav-link <?php echo e(request()->routeIs('cart.index') ? 'active' : ''); ?>"
            href="<?php echo e(route('cart.index')); ?>">
            Keranjang
            </a>
        </li>

        <li class="nav-item">
            <a class="nav-link <?php echo e(request()->routeIs('about') ? 'active' : ''); ?>"
            href="<?php echo e(route('about')); ?>">
            Tentang Kami
            </a>
        </li>

        <li class="nav-item">
            <a class="nav-link <?php echo e(request()->routeIs('user.orders') ? 'active' : ''); ?>"
            href="<?php echo e(route('user.orders')); ?>">
            📦 Riwayat Pesanan
            </a>
        </li>
      </ul>

      <form method="POST" action="<?php echo e(route('logout')); ?>">
          <?php echo csrf_field(); ?>
          <button type="submit" class="btn btn-danger">Logout</button>
      </form>
    </div>
  </div>
</nav><?php /**PATH C:\Coding\bootcampeduwork\ecommerce\resources\views\layouts\navbar.blade.php ENDPATH**/ ?>