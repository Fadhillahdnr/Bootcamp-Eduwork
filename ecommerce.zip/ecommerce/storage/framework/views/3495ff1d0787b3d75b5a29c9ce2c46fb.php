<nav x-data="{ open: false }"
     class="sticky top-0 z-50 backdrop-blur-xl"
     style="
        background: linear-gradient(
            to bottom,
            rgba(2,6,23,.85),
            rgba(2,6,23,.65)
        );
        border-bottom: 1px solid var(--border-soft);
     ">

    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="flex justify-between h-16 items-center">

            
            <div class="flex items-center gap-10">

                
                <a href="<?php echo e(route('beranda')); ?>" class="flex items-center gap-3 group">
                    <?php if (isset($component)) { $__componentOriginal8892e718f3d0d7a916180885c6f012e7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8892e718f3d0d7a916180885c6f012e7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.application-logo','data' => ['class' => 'h-9 w-auto transition group-hover:scale-105','style' => 'fill: var(--primary);']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('application-logo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'h-9 w-auto transition group-hover:scale-105','style' => 'fill: var(--primary);']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8892e718f3d0d7a916180885c6f012e7)): ?>
<?php $attributes = $__attributesOriginal8892e718f3d0d7a916180885c6f012e7; ?>
<?php unset($__attributesOriginal8892e718f3d0d7a916180885c6f012e7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8892e718f3d0d7a916180885c6f012e7)): ?>
<?php $component = $__componentOriginal8892e718f3d0d7a916180885c6f012e7; ?>
<?php unset($__componentOriginal8892e718f3d0d7a916180885c6f012e7); ?>
<?php endif; ?>
                    <span class="font-bold tracking-wide text-lg"
                          style="color: var(--text-main);">
                        Toko Online
                    </span>
                </a>

                
                <div class="hidden sm:flex items-center gap-6">
                    <?php
                        function navActive($route) {
                            return request()->routeIs($route)
                                ? 'nav-premium active'
                                : 'nav-premium';
                        }
                    ?>

                    <a href="<?php echo e(route('beranda')); ?>" class="<?php echo e(navActive('beranda')); ?>">Beranda</a>
                    <a href="<?php echo e(route('cart.index')); ?>" class="<?php echo e(navActive('cart.*')); ?>">Keranjang</a>
                    <a href="<?php echo e(route('about')); ?>" class="<?php echo e(navActive('about')); ?>">Tentang Kami</a>

                    <?php if(auth()->guard()->check()): ?>
                        <a href="<?php echo e(route('user.orders')); ?>" class="<?php echo e(navActive('user.orders*')); ?>">
                            📦 Riwayat Pesanan
                        </a>
                    <?php endif; ?>
                </div>
            </div>

            
            <div class="hidden sm:flex items-center gap-4">

                <?php if(auth()->guard()->check()): ?>
                    
                    <div class="relative" x-data="{ openUser: false }">
                        <button @click="openUser = !openUser"
                            class="flex items-center gap-3 px-3 py-2 rounded-xl transition hover:scale-[1.02]"
                            style="background: var(--bg-card); border:1px solid var(--border-soft);">

                            
                            <div class="w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm"
                                 style="background: var(--primary); color:white;">
                                <?php echo e(strtoupper(substr(Auth::user()->name,0,1))); ?>

                            </div>

                            <span class="font-medium"
                                  style="color: var(--text-main);">
                                <?php echo e(Auth::user()->name); ?>

                            </span>

                            <svg class="w-4 h-4 opacity-60" fill="currentColor" viewBox="0 0 20 20">
                                <path fill-rule="evenodd"
                                      d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z"/>
                            </svg>
                        </button>

                        
                        <div x-show="openUser" x-transition @click.away="openUser=false"
                             class="absolute right-0 mt-3 w-48 rounded-xl overflow-hidden shadow-2xl"
                             style="background: var(--bg-card); border:1px solid var(--border-soft);">

                            <a href="<?php echo e(route('profile.edit')); ?>" class="dropdown-item">
                                👤 Profile
                            </a>

                            <form method="POST" action="<?php echo e(route('logout')); ?>">
                                <?php echo csrf_field(); ?>
                                <button class="dropdown-item text-danger w-full text-left">
                                    🚪 Logout
                                </button>
                            </form>
                        </div>
                    </div>
                <?php endif; ?>

                <?php if(auth()->guard()->guest()): ?>
                    <a href="<?php echo e(route('login')); ?>"
                       class="btn btn-primary px-5 py-2 rounded-xl shadow-sm">
                        Login
                    </a>
                <?php endif; ?>
            </div>

            
            <div class="sm:hidden">
                <button @click="open = !open"
                        class="text-xl px-3 py-2 rounded-lg"
                        style="color: var(--text-main);">
                    ☰
                </button>
            </div>
        </div>
    </div>

    
    <div x-show="open" x-transition
         class="sm:hidden px-4 py-5 space-y-2"
         style="background: var(--bg-soft); border-top:1px solid var(--border-soft);">

        <a href="<?php echo e(route('beranda')); ?>" class="mobile-link">Beranda</a>
        <a href="<?php echo e(route('cart.index')); ?>" class="mobile-link">Keranjang</a>
        <a href="<?php echo e(route('about')); ?>" class="mobile-link">Tentang Kami</a>

        <?php if(auth()->guard()->check()): ?>
            <a href="<?php echo e(route('user.orders')); ?>" class="mobile-link">📦 Riwayat Pesanan</a>
            <form method="POST" action="<?php echo e(route('logout')); ?>">
                <?php echo csrf_field(); ?>
                <button class="mobile-link text-danger w-full text-left">
                    Logout
                </button>
            </form>
        <?php endif; ?>

        <?php if(auth()->guard()->guest()): ?>
            <a href="<?php echo e(route('login')); ?>" class="mobile-link">Login</a>
        <?php endif; ?>
    </div>
</nav>
<?php /**PATH C:\Coding\bootcampeduwork\ecommerce\resources\views/user/layouts/navigation.blade.php ENDPATH**/ ?>