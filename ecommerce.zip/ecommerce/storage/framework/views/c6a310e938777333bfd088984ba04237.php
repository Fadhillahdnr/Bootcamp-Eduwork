

<?php $__env->startSection('title','Riwayat Pesanan'); ?>

<?php $__env->startSection('content'); ?>
<div class="container my-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>📦 Riwayat Pesanan Saya</h2>
        <a href="<?php echo e(route('user.dashboard')); ?>" class="btn btn-secondary">← Kembali</a>
    </div>

    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php if($orders->count()): ?>
        <div class="table-responsive">
            <table class="table table-hover table-bordered">
                <thead class="table-dark">
                    <tr>
                        <th>ID Pesanan</th>
                        <th>Tanggal</th>
                        <th>Total</th>
                        <th>Metode Pembayaran</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <strong>#<?php echo e($order->id); ?></strong>
                            </td>
                            <td>
                                <?php echo e($order->created_at->format('d M Y H:i')); ?>

                            </td>
                            <td>
                                <strong>Rp <?php echo e(number_format($order->total)); ?></strong>
                            </td>
                            <td>
                                <span class="badge bg-primary">
                                    <?php echo e(strtoupper($order->payment_method)); ?>

                                </span>
                            </td>
                            <td>
                                <?php
                                    $statusColor = match($order->status) {
                                        'diproses' => 'warning',
                                        'dikirim' => 'info',
                                        'selesai' => 'success',
                                        'menunggu pembayaran' => 'danger',
                                        default => 'secondary'
                                    };
                                ?>
                                <span class="badge bg-<?php echo e($statusColor); ?>">
                                    <?php echo e(ucfirst($order->status)); ?>

                                </span>
                            </td>
                            <td>
                                <a href="<?php echo e(route('user.orders.detail', $order->id)); ?>"
                                   class="btn btn-sm btn-primary">
                                    📋 Detail
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    <?php else: ?>
        <div class="alert alert-info text-center py-5">
            <h5>Belum ada pesanan</h5>
            <p class="mb-3">Anda belum melakukan pemesanan apapun.</p>
            <a href="<?php echo e(route('product')); ?>" class="btn btn-primary">
                🛍️ Mulai Belanja
            </a>
        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Coding\bootcampeduwork\ecommerce\resources\views\user\orderhistory.blade.php ENDPATH**/ ?>