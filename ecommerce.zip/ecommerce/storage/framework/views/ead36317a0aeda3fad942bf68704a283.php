

<?php $__env->startSection('title','Daftar Pesanan'); ?>

<?php $__env->startSection('content'); ?>
<div class="container my-4 text-dark">

    
    <div class="d-flex flex-wrap justify-content-between align-items-center mb-4 gap-3">
        <div>
            <h4 class="fw-bold mb-1">
                <i class="bi bi-box-seam me-2 text-primary"></i>Daftar Pesanan
            </h4>
            <small class="text-muted">
                Kelola dan pantau seluruh pesanan pelanggan
            </small>
        </div>

        <a href="<?php echo e(route('admin.dashboard')); ?>"
           class="btn btn-outline-secondary rounded-pill px-4">
            <i class="bi bi-arrow-left me-1"></i>Kembali
        </a>
    </div>

    
    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show shadow-sm">
            <i class="bi bi-check-circle me-2"></i>
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    
    <div class="card border-0 shadow-sm rounded-4">
        <div class="card-header bg-white border-0 d-flex justify-content-between align-items-center">
            <h6 class="fw-semibold mb-0">
                Total Pesanan
                <span class="badge bg-primary ms-2">
                    <?php echo e($orders->total()); ?>

                </span>
            </h6>
        </div>

        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="text-center" style="background:#f1f5f9">
                        <tr class="small text-uppercase text-muted">
                            <th>ID</th>
                            <th>Pembeli</th>
                            <th>Email</th>
                            <th>Total</th>
                            <th>Metode</th>
                            <th>Status</th>
                            <th>Tanggal</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                
                                <td class="text-center fw-semibold text-primary">
                                    #<?php echo e($order->id); ?>

                                </td>

                                
                                <td class="fw-semibold">
                                    <?php echo e($order->name); ?>

                                </td>

                                
                                <td>
                                    <?php if($order->user): ?>
                                        <small class="text-muted">
                                            <?php echo e($order->user->email); ?>

                                        </small>
                                    <?php else: ?>
                                        <span class="text-muted">—</span>
                                    <?php endif; ?>
                                </td>

                                
                                <td class="fw-bold text-success">
                                    Rp <?php echo e(number_format($order->total)); ?>

                                </td>


                                
                                <td class="text-center">
                                    <span class="badge rounded-pill bg-primary text-white px-3 py-2">
                                        <?php echo e(strtoupper($order->payment_method)); ?>

                                    </span>
                                </td>

                                
                                <td class="text-center">
                                    <?php
                                        $statusMap = [
                                            'diproses' => 'warning',
                                            'dikirim' => 'info',
                                            'selesai' => 'success',
                                            'menunggu pembayaran' => 'danger',
                                            'dibatalkan' => 'secondary'
                                        ];
                                        $statusColor = $statusMap[$order->status] ?? 'secondary';
                                    ?>

                                    <span class="badge rounded-pill bg-<?php echo e($statusColor); ?> text-white px-3 py-2">
                                        <?php echo e(ucfirst($order->status)); ?>

                                    </span>
                                </td>

                                
                                <td class="text-center">
                                    <small class="text-secondary fw-medium">
                                        <?php echo e($order->created_at->format('d M Y')); ?><br>
                                        <?php echo e($order->created_at->format('H:i')); ?>

                                    </small>
                                </td>

                                
                                <td class="text-center">
                                    <a href="<?php echo e(route('admin.orders.show', $order->id)); ?>"
                                       class="btn btn-sm btn-outline-primary rounded-pill px-3">
                                        <i class="bi bi-eye me-1"></i>Detail
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="8" class="text-center py-5 text-muted">
                                    <i class="bi bi-inbox fs-3 d-block mb-2"></i>
                                    Belum ada pesanan masuk
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    
    <?php if($orders->hasPages()): ?>
        <div class="d-flex justify-content-center mt-4">
            <?php echo e($orders->links()); ?>

        </div>
    <?php endif; ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Coding\bootcampeduwork\ecommerce\resources\views/admin/orders/index.blade.php ENDPATH**/ ?>