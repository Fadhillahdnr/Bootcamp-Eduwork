    <?php
        use Illuminate\Support\Str;
    ?>

    

    <?php $__env->startSection('title','Beranda'); ?>

    <?php $__env->startSection('content'); ?>

    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div> 
    <?php endif; ?>

    <?php if (isset($component)) { $__componentOriginalb5e767ad160784309dfcad41e788743b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb5e767ad160784309dfcad41e788743b = $attributes; } ?>
<?php $component = App\View\Components\Alert::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Alert::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        Selamat Datang di Toko Kami
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb5e767ad160784309dfcad41e788743b)): ?>
<?php $attributes = $__attributesOriginalb5e767ad160784309dfcad41e788743b; ?>
<?php unset($__attributesOriginalb5e767ad160784309dfcad41e788743b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb5e767ad160784309dfcad41e788743b)): ?>
<?php $component = $__componentOriginalb5e767ad160784309dfcad41e788743b; ?>
<?php unset($__componentOriginalb5e767ad160784309dfcad41e788743b); ?>
<?php endif; ?>

    <div class="container">
        <div class="row mb-4 mt-4">
            <div class="col-md-3">
                <div class="card text-center shadow-sm">
                    <div class="card-body">
                        <h5 class="card-title">📦 Riwayat Pesanan</h5>
                        <p class="card-text">Lihat semua pesanan Anda</p>
                        <a href="<?php echo e(route('user.orders')); ?>" class="btn btn-primary">Lihat Pesanan</a>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card text-center shadow-sm">
                    <div class="card-body">
                        <h5 class="card-title">🛒 Keranjang Saya</h5>
                        <p class="card-text">Lanjutkan belanja</p>
                        <a href="<?php echo e(route('cart.index')); ?>" class="btn btn-primary">Buka Keranjang</a>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-12 text-center my-4">
            <h1>Welcome to Our Store</h1>
            <p class="lead">Discover our exclusive products below</p>
        </div>

        
        <form method="GET" action="<?php echo e(route('user.dashboard')); ?>" class="mb-4">
            <div class="row justify-content-center">
                <div class="col-md-4">
                    <select name="category" class="form-select" onchange="this.form.submit()">
                        <option value="">-- Semua Kategori --</option>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($category->id); ?>"
                                <?php echo e(request('category') == $category->id ? 'selected' : ''); ?>>
                                <?php echo e($category->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
        </form>

        
        <div class="row justify-content-center g-4">
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-3 mb-4">
                    <div class="card h-100">
                        <img src="<?php echo e(asset('storage/'.$product->image)); ?>"
                            class="card-img-top product-image">
                        
                        <div class="card-body d-flex flex-column">
                            <span class="badge bg-secondary mb-2">
                                <?php echo e($product->category->name); ?>

                            </span>
                            
                            <h5 class="card-title"><?php echo e($product->name); ?></h5>
                            <p class="card-text">
                                <?php echo e(Str::limit($product->description, 80)); ?>

                            </p>
                            <?php if(strlen($product->description) > 80): ?>
                                <a class="text-decoration-none"
                                data-bs-toggle="collapse"
                                href="#desc-<?php echo e($product->id); ?>"
                                role="button">
                                    Baca selengkapnya
                                </a>

                                <div class="collapse mt-2" id="desc-<?php echo e($product->id); ?>">
                                    <p class="card-text">
                                        <?php echo e($product->description); ?>

                                    </p>

                                    <a class="text-decoration-none"
                                    data-bs-toggle="collapse"
                                    href="#desc-<?php echo e($product->id); ?>">
                                        Tutup
                                    </a>
                                </div>
                            <?php endif; ?>

                            <div class="mt-auto">
                                <p class="fw-bold text-success">
                                    Rp <?php echo e(number_format($product->price)); ?>

                                </p>
                                <a href="<?php echo e(route('product.show', $product->id)); ?>" class="btn btn-primary">Detail</a>
                                <a href="<?php echo e(route('cart.add', $product->id)); ?>" class="btn btn-success mt-2">
                                    Tambah ke Keranjang
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>

    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Coding\bootcampeduwork\ecommerce\resources\views\user\dashboard.blade.php ENDPATH**/ ?>