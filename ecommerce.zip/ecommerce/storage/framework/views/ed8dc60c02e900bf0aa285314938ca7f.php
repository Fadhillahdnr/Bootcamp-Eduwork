<nav x-data="{ open: false }"
     class="sticky top-0 z-50 border-b"
     style="background-color: var(--bg-soft); border-color: var(--border-soft);">

    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="flex justify-between h-16">

            <!-- LEFT -->
            <div class="flex items-center gap-10">

                <!-- LOGO -->
                <a href="<?php echo e(route('admin.dashboard')); ?>"
                   class="flex items-center gap-2 font-bold text-lg"
                   style="color: var(--text-main);">
                    <?php if (isset($component)) { $__componentOriginal8892e718f3d0d7a916180885c6f012e7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8892e718f3d0d7a916180885c6f012e7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.application-logo','data' => ['class' => 'h-9 w-auto','style' => 'fill: var(--primary);']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('application-logo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'h-9 w-auto','style' => 'fill: var(--primary);']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8892e718f3d0d7a916180885c6f012e7)): ?>
<?php $attributes = $__attributesOriginal8892e718f3d0d7a916180885c6f012e7; ?>
<?php unset($__attributesOriginal8892e718f3d0d7a916180885c6f012e7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8892e718f3d0d7a916180885c6f012e7)): ?>
<?php $component = $__componentOriginal8892e718f3d0d7a916180885c6f012e7; ?>
<?php unset($__componentOriginal8892e718f3d0d7a916180885c6f012e7); ?>
<?php endif; ?>
                    <span>Admin Panel</span>
                </a>

                <!-- MENU -->
                <div class="hidden sm:flex items-center gap-6">

                    <a href="<?php echo e(route('admin.dashboard')); ?>"
                       class="admin-nav-link <?php echo e(request()->routeIs('admin.dashboard') ? 'active' : ''); ?>">
                        📊 Dashboard
                    </a>

                    <a href="<?php echo e(route('admin.orders')); ?>"
                       class="admin-nav-link <?php echo e(request()->routeIs('admin.orders*') ? 'active' : ''); ?>">
                        📦 Pesanan
                    </a>

                    <a href="<?php echo e(route('admin.products.index')); ?>"
                       class="admin-nav-link <?php echo e(request()->routeIs('admin.products*') ? 'active' : ''); ?>">
                        🛒 Produk
                    </a>

                </div>
            </div>

            <!-- RIGHT -->
            <div class="hidden sm:flex items-center gap-4">

                <!-- USER DROPDOWN -->
                <div x-data="{ openUser:false }" class="relative">

                    <button @click="openUser=!openUser"
                        class="flex items-center gap-2 px-3 py-2 rounded-lg transition"
                        style="background: var(--bg-card); color: var(--text-main);">

                        <span class="font-medium"><?php echo e(Auth::user()->name); ?></span>
                        <svg class="w-4 h-4 opacity-70" fill="currentColor" viewBox="0 0 20 20">
                            <path fill-rule="evenodd"
                                d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z"/>
                        </svg>
                    </button>

                    <!-- DROPDOWN -->
                    <div x-show="openUser" @click.away="openUser=false"
                        class="absolute right-0 mt-2 w-44 rounded-xl shadow-lg overflow-hidden"
                        style="background: var(--bg-card); border:1px solid var(--border-soft);">

                        <a href="<?php echo e(route('profile.edit')); ?>"
                           class="dropdown-item">
                            👤 Profile
                        </a>

                        <form method="POST" action="<?php echo e(route('logout')); ?>">
                            <?php echo csrf_field(); ?>
                            <button class="dropdown-item text-danger w-full text-left">
                                🚪 Logout
                            </button>
                        </form>
                    </div>
                </div>
            </div>

            <!-- MOBILE BUTTON -->
            <div class="flex items-center sm:hidden">
                <button @click="open=!open"
                    class="p-2 rounded-lg"
                    style="color: var(--text-main);">
                    ☰
                </button>
            </div>

        </div>
    </div>

    <!-- MOBILE MENU -->
    <div x-show="open" class="sm:hidden px-4 py-4 space-y-2"
         style="background-color: var(--bg-soft); border-top:1px solid var(--border-soft);">

        <a href="<?php echo e(route('admin.dashboard')); ?>" class="mobile-link">Dashboard</a>
        <a href="<?php echo e(route('admin.orders')); ?>" class="mobile-link">Pesanan</a>
        <a href="<?php echo e(route('admin.products.index')); ?>" class="mobile-link">Produk</a>

        <form method="POST" action="<?php echo e(route('logout')); ?>">
            <?php echo csrf_field(); ?>
            <button class="mobile-link text-danger w-full text-left">
                Logout
            </button>
        </form>
    </div>
</nav>
<?php /**PATH C:\Coding\bootcampeduwork\ecommerce\resources\views/admin/layouts/navbar.blade.php ENDPATH**/ ?>