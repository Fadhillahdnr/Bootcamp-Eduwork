

<?php $__env->startSection('title','Produk'); ?>

<?php $__env->startSection('content'); ?>

<div class="container">

    <div class="d-flex justify-content-between align-items-center my-4">
        <h2>Daftar Produk</h2>

        <div>
            <a href="<?php echo e(url('/admin/products/create')); ?>" class="btn btn-success">
                + Tambah Produk
            </a>
            <a href="<?php echo e(url()->previous()); ?>" class="btn btn-secondary ms-2">
                ← Kembali
            </a>
        </div>
    </div>

    
    <form method="GET" action="<?php echo e(url('/admin/products')); ?>" class="mb-3">
        <div class="row g-2 align-items-center">
            <div class="col-md-4">
                <select name="category" class="form-select" onchange="this.form.submit()">
                    <option value="">-- Semua Kategori --</option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($category->id); ?>"
                            <?php echo e(request('category') == $category->id ? 'selected' : ''); ?>>
                            <?php echo e($category->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
    </form>

    <table class="table table-bordered">
        <thead class="table-dark">
            <tr>
                <th>No</th>
                <th>Gambar</th>
                <th>Nama Produk</th>
                <th>Kategori</th>
                <th>Deskripsi</th>
                <th>Harga</th>
                <th>Aksi</th>
            </tr>
        </thead>

        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td>
                        <img src="<?php echo e(asset('storage/'.$product->image)); ?>"
                             width="80" class="img-thumbnail">
                    </td>
                    <td><?php echo e($product->name); ?></td>
                    <td>
                        <?php echo e($product->category->name ?? '-'); ?>

                    </td>
                    <td><?php echo e($product->description); ?></td>
                    <td>Rp <?php echo e(number_format($product->price)); ?></td>
                    <td>
                        <a href="<?php echo e(url('/admin/products/'.$product->id.'/edit')); ?>"
                           class="btn btn-warning btn-sm">Edit</a>

                        <form action="<?php echo e(url('/admin/products/'.$product->id)); ?>"
                              method="POST" class="d-inline">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-danger btn-sm"
                                    onclick="return confirm('Yakin hapus?')">
                                Hapus
                            </button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="7" class="text-center">
                        Belum ada produk
                    </td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Coding\bootcampeduwork\ecommerce\resources\views/admin/products/index.blade.php ENDPATH**/ ?>