<?php $__env->startSection('title','Produk'); ?>

<?php $__env->startSection('content'); ?>
<div class="container my-5 text-dark">

    <div class="card shadow-sm border-0">
        <div class="card-body text-dark">

            
            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h4 class="fw-bold mb-1">📦 Daftar Produk</h4>
                    <small class="text-muted">
                        Kelola seluruh produk yang tersedia
                    </small>
                </div>

                <div class="d-flex gap-2">
                    <a href="<?php echo e(url('/admin/products/create')); ?>"
                       class="btn btn-dark btn-sm">
                        + Produk
                    </a>

                    <a href="<?php echo e(route('admin.dashboard')); ?>"
                       class="btn btn-outline-secondary btn-sm">
                        ← Kembali
                    </a>
                </div>
            </div>

            
            <form method="GET" action="<?php echo e(url('/admin/products')); ?>" class="mb-4">
                <div class="row">
                    <div class="col-md-4">
                        <select name="category"
                                class="form-select form-select-sm"
                                onchange="this.form.submit()">
                            <option value="">Semua Kategori</option>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($category->id); ?>"
                                    <?php echo e(request('category') == $category->id ? 'selected' : ''); ?>>
                                    <?php echo e($category->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
            </form>

            
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light">
                        <tr class="small text-muted text-center">
                            <th width="50">No</th>
                            <th>Produk</th>
                            <th>Kategori</th>
                            <th>Harga</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td class="fw-semibold">
                                    <?php echo e($loop->iteration); ?>

                                </td>

                                
                                <td>
                                    <div class="d-flex align-items-center gap-3">
                                        <img src="<?php echo e(asset('storage/'.$product->image)); ?>"
                                             width="55"
                                             height="55"
                                             class="rounded border object-fit-cover">

                                        <div>
                                            <div class="fw-semibold text-dark">
                                                <?php echo e($product->name); ?>

                                            </div>
                                            <small class="text-muted">
                                                <?php echo e(Str::limit($product->description, 45)); ?>

                                            </small>
                                        </div>
                                    </div>
                                </td>

                                
                                <td>
                                    <span class="badge bg-light text-dark border px-3 py-2">
                                        <?php echo e($product->category->name ?? '-'); ?>

                                    </span>
                                </td>

                                
                                <td class="fw-semibold">
                                    Rp <?php echo e(number_format($product->price)); ?>

                                </td>

                                
                                <td class="text-end ">
                                    <a href="<?php echo e(url('/admin/products/'.$product->id.'/edit')); ?>"
                                       class="btn btn-outline-warning btn-sm">
                                        ✏️ Edit
                                    </a>

                                    <form action="<?php echo e(url('/admin/products/'.$product->id)); ?>"
                                          method="POST"
                                          class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit"
                                                class="btn btn-outline-danger btn-sm"
                                                onclick="return confirm('Yakin hapus produk ini?')">
                                            🗑 Hapus
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="5"
                                    class="text-center text-muted py-5">
                                    📭 Belum ada produk
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Coding\bootcampeduwork\ecommerce\resources\views/admin/products/index.blade.php ENDPATH**/ ?>