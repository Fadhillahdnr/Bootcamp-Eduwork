<footer class="mt-auto text-center py-3 bg-dark text-white">
    <small>
        © <?php echo e(date('Y')); ?> Toko Online — All rights reserved
    </small>
</footer>
<?php /**PATH C:\Coding\bootcampeduwork\ecommerce\resources\views/layouts/footer.blade.php ENDPATH**/ ?>