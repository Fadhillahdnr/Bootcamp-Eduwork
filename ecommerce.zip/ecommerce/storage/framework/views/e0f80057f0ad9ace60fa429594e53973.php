

<?php $__env->startSection('title','Daftar Pesanan'); ?>

<?php $__env->startSection('content'); ?>
<div class="container my-4"> 
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>📦 Daftar Pesanan</h2>
        <a href="<?php echo e(url()->previous()); ?>" class="btn btn-secondary">
            ← Kembali
        </a>    
    </div>

    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="card shadow-sm">
        <div class="card-header bg-dark text-white">
            <h5 class="mb-0">Total Pesanan: <?php echo e($orders->total()); ?></h5>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover table-bordered">
                    <thead class="table-dark">
                        <tr>
                            <th>ID</th>
                            <th>Pembeli</th>
                            <th>Email</th>
                            <th>Total</th>
                            <th>Metode</th>
                            <th>Status</th>
                            <th>Tanggal</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td>
                                    <strong>#<?php echo e($order->id); ?></strong>
                                </td>
                                <td><?php echo e($order->name); ?></td>
                                <td>
                                    <?php if($order->user): ?>
                                        <small><?php echo e($order->user->email); ?></small>
                                    <?php else: ?>
                                        <span class="text-muted">-</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <strong>Rp <?php echo e(number_format($order->total)); ?></strong>
                                </td>
                                <td>
                                    <span class="badge bg-primary">
                                        <?php echo e(strtoupper($order->payment_method)); ?>

                                    </span>
                                </td>
                                <td>
                                    <?php
                                        $statusColor = match($order->status) {
                                            'diproses' => 'warning',
                                            'dikirim' => 'info',
                                            'selesai' => 'success',
                                            'menunggu pembayaran' => 'danger',
                                            'dibatalkan' => 'secondary',
                                            default => 'secondary'
                                        };
                                    ?>
                                    <span class="badge bg-<?php echo e($statusColor); ?>">
                                        <?php echo e(ucfirst($order->status)); ?>

                                    </span>
                                </td>
                                <td>
                                    <small><?php echo e($order->created_at->format('d M Y H:i')); ?></small>
                                </td>
                                <td>
                                    <a href="<?php echo e(route('admin.orders.show', $order->id)); ?>"
                                       class="btn btn-sm btn-primary">
                                       📋 Detail
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="8" class="text-center py-4 text-muted">
                                    Belum ada pesanan
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Pagination -->
    <?php if($orders->hasPages()): ?>
        <div class="d-flex justify-content-center mt-4">
            <?php echo e($orders->links()); ?>

        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Coding\bootcampeduwork\ecommerce\resources\views\admin\orders\index.blade.php ENDPATH**/ ?>