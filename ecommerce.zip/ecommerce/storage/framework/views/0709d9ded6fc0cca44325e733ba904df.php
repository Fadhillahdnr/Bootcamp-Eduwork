<?php $__env->startSection('title','Keranjang'); ?>

<?php $__env->startSection('content'); ?>
<div class="container my-4">
    <h2>Keranjang Belanja</h2>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <strong>Terjadi kesalahan:</strong>
            <ul class="mb-0">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php echo e(session('error')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php if($cart && $cart->items->count()): ?>
        <table class="table table-bordered">
            <thead class="table-dark">
                <tr>
                    <th>Produk</th>
                    <th>Harga</th>
                    <th>Qty</th>
                    <th>Total</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $grandTotal = 0; ?>

                <?php $__currentLoopData = $cart->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $total = $item->product->price * $item->qty;
                        $grandTotal += $total;
                    ?>

                    <tr>
                        <td>
                            <img src="<?php echo e(asset('storage/'.$item->product->image)); ?>"
                                 width="60" class="me-2">

                            <?php echo e($item->product->name); ?>

                        </td>

                        <td>Rp <?php echo e(number_format($item->product->price)); ?></td>

                        <td class="text-center">
                            <a href="<?php echo e(route('cart.decrease', $item->id)); ?>"
                               class="btn btn-sm btn-outline-secondary">−</a>

                            <span class="mx-2"><?php echo e($item->qty); ?></span>

                            <a href="<?php echo e(route('cart.increase', $item->id)); ?>"
                               class="btn btn-sm btn-outline-secondary">+</a>
                        </td>

                        <td>Rp <?php echo e(number_format($total)); ?></td>

                        <td>
                            <a href="<?php echo e(route('cart.remove', $item->id)); ?>"
                               class="btn btn-danger btn-sm">
                                Hapus
                            </a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <tr>
                    <th colspan="3">Total</th>
                    <th colspan="2">Rp <?php echo e(number_format($grandTotal)); ?></th>
                </tr>
            </tbody>
        </table>

        <div class="d-flex gap-2 mt-3">
            <a href="<?php echo e(route('beranda')); ?>" class="btn btn-secondary">Lanjut Belanja</a>
            <a href="<?php echo e(route('checkout.index')); ?>" class="btn btn-primary">Checkout</a>
        </div>
    <?php else: ?>
        <p class="text-muted">Keranjang Anda masih kosong</p>
        <a href="<?php echo e(route('beranda')); ?>" class="btn btn-primary">Mulai Belanja</a>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Coding\bootcampeduwork\ecommerce\resources\views\pages\cart.blade.php ENDPATH**/ ?>