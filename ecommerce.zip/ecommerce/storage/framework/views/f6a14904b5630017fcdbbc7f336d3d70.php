

<?php $__env->startSection('title','Edit Produk'); ?>

<?php $__env->startSection('content'); ?>

<div class="container py-4">

    <div class="card shadow-sm border-0">
        <div class="card-body">

            
            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h5 class="fw-semibold mb-0">Edit Produk</h5>
                    <small class="text-muted">Perbarui informasi produk</small>
                </div>

                <a href="<?php echo e(url()->previous()); ?>"
                   class="btn btn-outline-secondary btn-sm">
                    ← Kembali
                </a>
            </div>

            
            <form method="POST"
                  action="<?php echo e(url('/admin/products/'.$product->id)); ?>"
                  enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="col-md-12">
                    <label class="form-label">Kategori</label>
                    <select name="category_id"
                            class="form-select"
                            required>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($category->id); ?>"
                                <?php echo e($product->category_id == $category->id ? 'selected' : ''); ?>>
                                <?php echo e($category->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="row g-3">

                    <div class="col-md-6">
                        <label class="form-label">Nama Produk</label>
                        <input type="text"
                               name="name"
                               value="<?php echo e(old('name', $product->name)); ?>"
                               class="form-control"
                               required>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label">Harga</label>
                        <input type="number"
                               name="price"
                               value="<?php echo e(old('price', $product->price)); ?>"
                               class="form-control"
                               required>
                    </div>

                    <div class="col-12">
                        <label class="form-label">Deskripsi</label>
                        <textarea name="description"
                                  rows="4"
                                  class="form-control"
                                  required><?php echo e(old('description', $product->description)); ?></textarea>
                    </div>

                    
                    <div class="col-md-6">
                        <label class="form-label">Gambar Sekarang</label>
                        <div>
                            <img src="<?php echo e(asset('storage/'.$product->image)); ?>"
                                 width="120"
                                 class="rounded border">
                        </div>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label">Ganti Gambar (opsional)</label>
                        <input type="file"
                               name="image"
                               class="form-control">
                    </div>

                </div>

                
                <div class="d-flex gap-2 mt-4">
                    <button class="btn btn-dark btn-sm">
                        Update Produk
                    </button>

                    <a href="<?php echo e(url('/admin/products')); ?>"
                       class="btn btn-outline-secondary btn-sm">
                        Batal
                    </a>
                </div>

            </form>

        </div>
    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Coding\bootcampeduwork\ecommerce\resources\views/admin/products/edit.blade.php ENDPATH**/ ?>