<footer class="mt-auto text-center py-3 bg-dark text-white">
    <small>
        © {{ date('Y') }} Toko Online — All rights reserved
    </small>
</footer>
