@extends('layouts.master')

@section('title','Product')
@section('content')
    <h1>Ini Daftar Produk kami</h1>
@endsection