<img src="/storage/products/logo.png" alt="logo" {{ $attributes->merge(['class' => 'w-20 h-20 fill-current text-gray-500']) }}>   
